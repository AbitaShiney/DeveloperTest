//
//  HomeViewController.swift
//  DemoApp
//
//  Created by Abita Shiney on 2020-01-06.
//  Copyright © 2020 Abita Shiney. All rights reserved.
//

import UIKit
import MessageUI

class HomeViewController: UIViewController {

    let transiton = SlideInTransition()
    var topView: UIView?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func didTapMenu(_ sender: UIBarButtonItem) {
        guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController else { return }
        menuViewController.didTapMenuType = { menuType in
            self.transitionToNew(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self
        present(menuViewController, animated: true)
    }

    func transitionToNew(_ menuType: MenuType) {
        let title = String(describing: menuType).capitalized
        self.title = title

        topView?.removeFromSuperview()
        switch menuType {
        case .sent:
            let view = UIView()
//            view.backgroundColor = .yellow
            view.frame = self.view.bounds
            self.view.addSubview(view)
            self.topView = view
            
        case .inbox:
            let view = UIView()
//            view.backgroundColor = .blue
            view.frame = self.view.bounds
            self.view.addSubview(view)
            self.topView = view
        default:
            break
        }
    }

}

extension HomeViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = true
        return transiton
    }

    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = false
        return transiton
    }
    //IBAction to open standard email interface
        @IBAction func emailButtonDidTouch(_ sender: UIButton) {
            
            //The mail composition interface
            //Use your own email address & subject
            let receipients = ["abitashiney@gmail.com"]
            let subject = "Test code"
            let messageBody = ""
            
            let configuredMailComposeViewController = configureMailComposeViewController(recepients: receipients, subject: subject, messageBody: messageBody)
            
           
            
            //Checking the availability of mail services
            if canSendMail() {
                self.present(configuredMailComposeViewController, animated: true, completion: nil)
                
                
            } else {
                showSendMailErrorAlert()
            }
        }
    }

    //MFMailComposeViewController Delegate
    extension HomeViewController: MFMailComposeViewControllerDelegate {
        
        //Configuring and presenting the composition interface
        func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
            
            // Dismiss the mail compose view controller.
            controller.dismiss(animated: true, completion: nil)
        }
        
        func canSendMail() -> Bool {
           
            return MFMailComposeViewController.canSendMail()
        }
        
        func configureMailComposeViewController(recepients: [String], subject: String, messageBody: String) -> MFMailComposeViewController {
            
            
            let mailComposerVC = MFMailComposeViewController()
            mailComposerVC.mailComposeDelegate = self
            
            mailComposerVC.setToRecipients(recepients)
            let newSub = mailComposerVC.setSubject(subject)
          
            mailComposerVC.setMessageBody(messageBody, isHTML: false)
            
            return mailComposerVC
        }
        
       
        
        func showSendMailErrorAlert() {
            let sendMailErrorAlert = UIAlertController(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", preferredStyle: .alert)
            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            
            sendMailErrorAlert.addAction(cancelAction)
            present(sendMailErrorAlert, animated: true, completion: nil)
        }
        
}

